/*
 End-to-end local test: signup → signin (client-signed payload) → verify
 Requires server running locally. Uses Node 18+ global fetch.
*/

const nacl = require('tweetnacl');
const { keyPairFromCid } = require('../src/crypto/keys');

function base64(u8) { return Buffer.from(u8).toString('base64'); }

async function main() {
  const salt = process.env.SECRET_SALT || 'default-salt-insecure-change-me';
  const baseUrl = process.env.TEST_BASE_URL || 'http://localhost:3100';

  const email = `user_${Math.floor(Math.random()*1e6)}@example.com`;
  const password = 'P@ssw0rd!';
  const cid = 'test-cid-12345';

  // 1) Signup
  let resp = await fetch(`${baseUrl}/api/auth/signup`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, password, cid })
  });
  let data = await resp.json();
  if (!resp.ok || !data.ok) {
    throw new Error(`Signup failed: ${resp.status} ${JSON.stringify(data)}`);
  }
  console.log('Signup ok:', data);

  // 2) Prepare client-signed payload
  const payload = { email, cid, timestamp: Date.now() };
  const { privateKey } = keyPairFromCid(cid, salt);
  const payloadBytes = Buffer.from(JSON.stringify(payload));
  const sig = nacl.sign.detached(payloadBytes, privateKey);
  const signature = base64(sig);

  // 3) Signin
  resp = await fetch(`${baseUrl}/api/auth/signin`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, password, cid, payload, signature })
  });
  data = await resp.json();
  if (!resp.ok || !data.ok) {
    throw new Error(`Signin failed: ${resp.status} ${JSON.stringify(data)}`);
  }
  console.log('Signin ok:', { user: data.user, token: data.token.slice(0, 24) + '...' });

  // 4) Verify token
  resp = await fetch(`${baseUrl}/api/auth/verify`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ token: data.token })
  });
  const verifyData = await resp.json();
  if (!resp.ok || !verifyData.ok) {
    throw new Error(`Verify failed: ${resp.status} ${JSON.stringify(verifyData)}`);
  }
  console.log('Verify ok:', verifyData.payload);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});


