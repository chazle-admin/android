## pv_auth backend (Node.js, Express, SQLite)

Offline-capable auth backend implementing signup/signin where the frontend provides a `cid` that deterministically derives an Ed25519 keypair. The private key is encrypted at rest and stored with the user. Signin requires a client-side signature for a payload `{ email, cid, timestamp }` which is verified using the stored public key. Server issues a short-lived server-signed token.

### Stack
- Node.js (>= 18)
- Express
- better-sqlite3 (embedded database, no internet required)
- tweetnacl (Ed25519)
- bcryptjs (password hashing)

### Setup
1. Copy `.env.example` to `.env` and set values:
   - `SECRET_SALT` — long random string (stable across runs)
   - Optionally set `MASTER_KEY_HEX` (64 hex chars) to encrypt private keys
   - `DATABASE_FILE` defaults to `./pv_auth.sqlite`
   - `PORT` defaults to `3000`

2. Install dependencies:
```bash
npm install
```

3. Start server:
```bash
npm start
```

4. Health check:
```bash
curl http://localhost:3000/health
```

### API

Base URL: `http://localhost:3000/api/auth`

#### Signup `POST /signup`
Request JSON:
```json
{ "email":"user@example.com", "password":"secret", "cid":"<client-cid>" }
```
Response:
```json
{ "ok": true, "userId": 1, "publicKey": "<base64>" }
```

#### Signin `POST /signin`
Client must sign the payload `{ email, cid, timestamp }` with the user's private key and send signature (base64) and payload.

Request JSON:
```json
{
  "email":"user@example.com",
  "password":"secret",
  "cid":"<client-cid>",
  "payload": { "email":"user@example.com", "cid":"<client-cid>", "timestamp": 1710000000000 },
  "signature": "<base64-signature-over-JSON(payload)>"
}
```

Response:
```json
{ "ok": true, "token": "<server-signed>", "serverPublicKey": "<base64>", "user": {"id":1,"email":"user@example.com"}}
```

#### Verify token `POST /verify`
Request:
```json
{ "token": "<server-signed>" }
```
Response:
```json
{ "ok": true, "payload": { "sub": 1, "email": "user@example.com", "iat": 1710000000000, "exp": 1710000900000 } }
```

### Security notes
- Ed25519 keypair is derived from `cid` + `SECRET_SALT` using scrypt, deterministic per user.
- Private key stored encrypted using a master key. Configure `MASTER_KEY_HEX` for stronger security.
- Signin requires fresh timestamp within 5 minutes to prevent replay.
- Server tokens are Ed25519 detached signatures, not JWT; trivial to verify using `serverPublicKey`.

### Development
- Database file is created automatically.
- To reset: stop server, delete the `.sqlite` file.


