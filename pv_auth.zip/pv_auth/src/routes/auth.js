const express = require('express');
const bcrypt = require('bcryptjs');
const nacl = require('tweetnacl');
const { keyPairFromCid, encryptPrivateKey, decryptPrivateKey, uint8ArrayToBase64, base64ToUint8Array, signPayload, verifySignature } = require('../crypto/keys');
const { createUser, findUserByEmail } = require('../models/user');

const router = express.Router();

function toBytes(obj) {
  return Buffer.from(JSON.stringify(obj));
}

// Signup: derive keys from cid, store hashed password, publicKey, encrypted privateKey
router.post('/signup', async (req, res) => {
  try {
    const { email, password, cid } = req.body || {};
    if (!email || !password || !cid) {
      return res.status(400).json({ error: 'email, password, cid are required' });
    }

    const existing = findUserByEmail(email);
    if (existing) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const salt = process.env.SECRET_SALT || 'default-salt-insecure-change-me';
    const { publicKey, privateKey } = keyPairFromCid(cid, salt);

    const enc = encryptPrivateKey(privateKey);
    const publicKeyB64 = uint8ArrayToBase64(publicKey);

    const userId = createUser({
      email,
      passwordHash,
      cid: String(cid),
      publicKeyB64: publicKeyB64,
      privateKeyEncrypted: enc,
    });

    return res.json({ ok: true, userId, publicKey: publicKeyB64 });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Signup error:', err);
    return res.status(500).json({ error: 'Internal error', details: String(err && err.message || err) });
  }
});

// Sign-in: verify password and verify client signature using stored public key
// Frontend should send a signature created with the private key over a payload { email, cid, timestamp }
// Server verifies the signature using the stored public key, then issues a short-lived server token (signed by server key derived from SECRET_SALT)
router.post('/signin', async (req, res) => {
  try {
    const { email, password, cid, signature, payload } = req.body || {};
    if (!email || !password || !cid) {
      return res.status(400).json({ error: 'email, password, cid are required' });
    }

    const user = findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (String(user.cid) !== String(cid)) {
      return res.status(401).json({ error: 'CID mismatch' });
    }

    // Require signature verification against stored public key
    if (!signature || !payload) {
      return res.status(400).json({ error: 'signature and payload are required' });
    }
    if (typeof payload !== 'object' || payload === null) {
      return res.status(400).json({ error: 'payload must be an object' });
    }
    const { email: pEmail, cid: pCid, timestamp } = payload;
    if (pEmail !== email || String(pCid) !== String(cid)) {
      return res.status(401).json({ error: 'Payload mismatch' });
    }
    const now = Date.now();
    const ts = Number(timestamp);
    if (!Number.isFinite(ts) || Math.abs(now - ts) > 5 * 60 * 1000) {
      return res.status(401).json({ error: 'Payload timestamp invalid or expired' });
    }
    const publicKeyU8 = base64ToUint8Array(user.public_key);
    const payloadBytes = Buffer.from(JSON.stringify(payload));
    const signatureU8 = base64ToUint8Array(signature);
    const verified = verifySignature(publicKeyU8, payloadBytes, signatureU8);
    if (!verified) {
      return res.status(401).json({ error: 'Signature verification failed' });
    }

    // Issue a simple token signed by server private key (derived from SECRET_SALT)
    const tokenPayload = { sub: user.id, email: user.email, iat: now, exp: now + 1000 * 60 * 15 };
    const { token, publicKeyB64 } = createServerSignedToken(tokenPayload);

    return res.json({ ok: true, token, serverPublicKey: publicKeyB64, user: { id: user.id, email: user.email } });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Signin error:', err);
    return res.status(500).json({ error: 'Internal error', details: String(err && err.message || err) });
  }
});

router.post('/verify', (req, res) => {
  try {
    const { token } = req.body || {};
    if (!token) return res.status(400).json({ error: 'token required' });
    const info = verifyServerSignedToken(token);
    return res.json({ ok: true, payload: info.payload });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token', details: String(err && err.message || err) });
  }
});

// Simple detached-signature token format: base64url(JSON.payload).base64url(signature)
function base64url(input) {
  return Buffer.from(input).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function base64urlToBuffer(b64url) {
  const b64 = b64url.replace(/-/g, '+').replace(/_/g, '/');
  const pad = b64.length % 4 === 2 ? '==' : b64.length % 4 === 3 ? '=' : '';
  return Buffer.from(b64 + pad, 'base64');
}

function getServerKeyPair() {
  const salt = process.env.SECRET_SALT || 'default-salt-insecure-change-me';
  const { publicKey, privateKey } = require('../crypto/keys').keyPairFromCid('server', salt);
  return { publicKey, privateKey };
}

function createServerSignedToken(payloadObj) {
  const { publicKey, privateKey } = getServerKeyPair();
  const payloadJson = JSON.stringify(payloadObj);
  const payloadB64url = base64url(payloadJson);
  const sig = nacl.sign.detached(Buffer.from(payloadJson), privateKey);
  const sigB64url = base64url(Buffer.from(sig));
  return { token: `${payloadB64url}.${sigB64url}`, publicKeyB64: Buffer.from(publicKey).toString('base64') };
}

function verifyServerSignedToken(token) {
  const parts = String(token).split('.');
  if (parts.length !== 2) throw new Error('Malformed token');
  const [payloadB64url, sigB64url] = parts;
  const payloadBuf = base64urlToBuffer(payloadB64url);
  const sigBuf = base64urlToBuffer(sigB64url);
  const { publicKey } = getServerKeyPair();
  const ok = nacl.sign.detached.verify(payloadBuf, new Uint8Array(sigBuf), publicKey);
  if (!ok) throw new Error('Signature invalid');
  const payload = JSON.parse(payloadBuf.toString('utf8'));
  if (payload.exp && Date.now() > payload.exp) throw new Error('Token expired');
  return { payload };
}

module.exports = router;


