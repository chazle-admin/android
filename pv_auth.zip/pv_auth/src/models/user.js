const { getDb } = require('../db');

function createUser({ email, passwordHash, cid, publicKeyB64, privateKeyEncrypted }) {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO users (email, password_hash, cid, public_key, private_key_encrypted)
    VALUES (@email, @password_hash, @cid, @public_key, @private_key_encrypted)
  `);

  const payload = {
    email,
    password_hash: passwordHash,
    cid,
    public_key: publicKeyB64,
    private_key_encrypted: JSON.stringify(privateKeyEncrypted),
  };
  const info = stmt.run(payload);
  return info.lastInsertRowid;
}

function findUserByEmail(email) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!row) return null;
  try {
    row.private_key_encrypted = JSON.parse(row.private_key_encrypted);
  } catch (_e) {
    // keep as is
  }
  return row;
}

module.exports = { createUser, findUserByEmail };


