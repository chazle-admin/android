const crypto = require('crypto');
const nacl = require('tweetnacl');

let cachedMasterKey = null;

function getMasterKey() {
  if (cachedMasterKey) return cachedMasterKey;

  const provided = process.env.MASTER_KEY_HEX;
  if (provided && provided.trim().length > 0) {
    try {
      const buf = Buffer.from(provided.trim(), 'hex');
      if (buf.length === 32) {
        cachedMasterKey = new Uint8Array(buf);
        return cachedMasterKey;
      }
      // eslint-disable-next-line no-console
      console.warn('MASTER_KEY_HEX invalid length; falling back to derived key');
    } catch (_e) {
      // eslint-disable-next-line no-console
      console.warn('MASTER_KEY_HEX invalid hex; falling back to derived key');
    }
  }

  const secretSalt = process.env.SECRET_SALT || 'default-salt-insecure-change-me';
  // Derive master key using HMAC-SHA256(secretSalt, 'pv_auth_master_key') for offline friendliness
  const h = crypto.createHmac('sha256', secretSalt);
  h.update('pv_auth_master_key');
  const derived = h.digest(); // 32 bytes
  cachedMasterKey = new Uint8Array(derived);
  return cachedMasterKey;
}

module.exports = { getMasterKey };


