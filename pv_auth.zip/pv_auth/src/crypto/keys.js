const crypto = require('crypto');
const nacl = require('tweetnacl');
const naclUtil = require('tweetnacl-util');
const { getMasterKey } = require('./secret');

function base64ToUint8Array(b64) {
  return new Uint8Array(Buffer.from(b64, 'base64'));
}

function uint8ArrayToBase64(u8) {
  return Buffer.from(u8).toString('base64');
}

function deriveSeedFromCid(cid, salt) {
  // Deterministically derive a 32-byte seed from cid + salt using HMAC-SHA256 (offline-friendly)
  const h = crypto.createHmac('sha256', String(salt));
  h.update(String(cid));
  const digest = h.digest(); // 32 bytes
  return new Uint8Array(digest);
}

function keyPairFromCid(cid, salt) {
  const seed = deriveSeedFromCid(cid, salt);
  const keyPair = nacl.sign.keyPair.fromSeed(seed);
  return {
    publicKey: keyPair.publicKey,
    privateKey: keyPair.secretKey,
  };
}

function encryptPrivateKey(privateKeyU8) {
  const masterKey = getMasterKey(); // Uint8Array length 32
  const nonce = nacl.randomBytes(nacl.secretbox.nonceLength);
  const boxed = nacl.secretbox(privateKeyU8, nonce, masterKey);
  return {
    nonceB64: uint8ArrayToBase64(nonce),
    ciphertextB64: uint8ArrayToBase64(boxed),
  };
}

function decryptPrivateKey(nonceB64, ciphertextB64) {
  const masterKey = getMasterKey();
  const nonce = base64ToUint8Array(nonceB64);
  const ciphertext = base64ToUint8Array(ciphertextB64);
  const opened = nacl.secretbox.open(ciphertext, nonce, masterKey);
  if (!opened) {
    throw new Error('Failed to decrypt private key');
  }
  return opened;
}

function signPayload(privateKeyU8, payloadBytes) {
  return nacl.sign.detached(payloadBytes, privateKeyU8);
}

function verifySignature(publicKeyU8, payloadBytes, signatureU8) {
  return nacl.sign.detached.verify(payloadBytes, signatureU8, publicKeyU8);
}

module.exports = {
  keyPairFromCid,
  encryptPrivateKey,
  decryptPrivateKey,
  signPayload,
  verifySignature,
  uint8ArrayToBase64,
  base64ToUint8Array,
};


