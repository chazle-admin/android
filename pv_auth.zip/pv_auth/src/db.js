const path = require('path');
const Database = require('better-sqlite3');

const DB_FILE = process.env.DATABASE_FILE || path.join(process.cwd(), 'pv_auth.sqlite');

let dbInstance = null;

function getDb() {
  if (!dbInstance) {
    dbInstance = new Database(DB_FILE);
    dbInstance.pragma('journal_mode = WAL');
    dbInstance.pragma('foreign_keys = ON');
  }
  return dbInstance;
}

function ensureDatabase() {
  const db = getDb();
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      cid TEXT NOT NULL,
      public_key TEXT NOT NULL,
      private_key_encrypted BLOB NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE UNIQUE INDEX IF NOT EXISTS users_email_idx ON users(email);
  `);
}

module.exports = { getDb, ensureDatabase };


