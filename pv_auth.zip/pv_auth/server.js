const path = require('path');
require('dotenv').config({ path: path.join(process.cwd(), '.env') });

const express = require('express');
const bodyParser = require('express').json;
const { ensureDatabase } = require('./src/db');
const authRouter = require('./src/routes/auth');

const app = express();
app.use(bodyParser({ limit: '1mb' }));

app.get('/health', (_req, res) => {
  res.json({ ok: true });
});

app.use('/api/auth', authRouter);

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;

ensureDatabase();

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`Server listening on http://localhost:${PORT}`);
});


